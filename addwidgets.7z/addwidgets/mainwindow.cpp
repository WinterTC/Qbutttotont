#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QtWidgets"
//int MainWindow::i =3;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    m_Button();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::ClickRemoteButton_1()
{
    static int i =4;
    layout->removeWidget(button[i]);
    i++;
}

void MainWindow::ClickAddButton_1()
{
    static int i =4;
    button[i] = new QPushButton(tr("Button %1").arg(i+1));
    layout->addWidget(button[i]);
    i++;
}
void MainWindow::m_Button()
{
    //QPushButton *button = new QPushButton(this);
    QGroupBox *mainlayout = new QGroupBox;
    QPushButton *button_1 = new QPushButton("Button 1");
    QPushButton *button_2 = new QPushButton("Button 2");
    QPushButton *button_3 = new QPushButton("Button 3");
    QPushButton *button_4 = new QPushButton("Button 4");

    layout = new QGridLayout;
    layout->addWidget(button_1,0,1);
    layout->addWidget(button_2,1,1);
    layout->addWidget(button_3,0,3);
    layout->addWidget(button_4,1,3);
    connect(button_1, SIGNAL(clicked()),this, SLOT(ClickAddButton_1()));
    connect(button_2, SIGNAL(clicked()),this, SLOT(ClickRemoteButton_1()));
    mainlayout->setLayout(layout);
    setCentralWidget(mainlayout);
    //button->setLayout(layout);
    // button->show();
   // setCentralWidget(button);

}

