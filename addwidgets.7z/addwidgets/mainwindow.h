#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "QtWidgets"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
private slots:
    void ClickAddButton_1();
    void ClickRemoteButton_1();
private:
    Ui::MainWindow *ui;
    void m_Button();
    QPushButton *button[];
    QGridLayout *layout;
};

#endif // MAINWINDOW_H
