#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QDebug"
#include "QPoint"
#include "QtWidgets"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter Painter(this);
    QPen Pointpen(Qt::black);
    Pointpen.setWidth(10);

    QPen Linepen(Qt::red);
    Linepen.setWidth(3);

    QPoint P1;
    P1.setX(170);
    P1.setY(130);

    QPoint P2;
    P2.setX(250);
    P2.setY(130);

    QPoint P3;
    P3.setX(250);
    P3.setY(70);

    QPoint P4;
    P4.setX(250);
    P4.setY(190);

    QPoint P5;
    P5.setX(320);
    P5.setY(130);

    Painter.setPen(Linepen);
    Painter.drawLine(P1,P2);
    Painter.drawLine(P2,P3);
    Painter.drawLine(P2,P4);
    Painter.drawLine(P2,P5);


    Painter.setPen(Pointpen);
    Painter.drawPoint(P1);
    Painter.drawPoint(P2);
    Painter.drawPoint(P3);
    Painter.drawPoint(P4);
    Painter.drawPoint(P5);

    QPushButton *button = new QPushButton("Trace",this);
    QRect rec(250,130,250,70);
    button->setGeometry(rec);
    button->show();

    QPushButton *button2 = new QPushButton("Node",this);
    QRect rec1(250,50,50,50);
    button2->setGeometry(rec1);
    button2->show();

    //Painter.drawLine(rec);

    static const QPointF points[3] = {
        QPointF(10, 20),
        QPointF(10, 80),
        QPointF(50, 80),
    };

    Painter.drawPolyline(points, 3);



}


void MainWindow::on_pushButton_clicked()
{
    //qDebug()<<ui->pushButton->cursor().pos();//screen coordinates
    qDebug()<<ui->pushButton->mapFromGlobal(ui->pushButton->cursor().pos());//local coordinates
}

void MainWindow::on_pushButton_2_clicked()
{
    qDebug()<<ui->pushButton->cursor().pos();//screen coordinates
    qDebug()<<ui->pushButton->mapFromGlobal(ui->pushButton->cursor().pos());//local coordinates
}
